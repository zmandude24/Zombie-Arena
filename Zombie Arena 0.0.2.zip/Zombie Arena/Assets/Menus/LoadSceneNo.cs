﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Gamemenu
{

    public class LoadSceneNo : MonoBehaviour
    {
        [SerializeField] private int i = 0;

        private Button button;


        void Start()
        {
            button = GetComponent<Button>();
        }


        void Update()
        {
            button.onClick.AddListener(Load_Scene);
        }

        private void Load_Scene()
        {
            SceneManager.LoadScene(i);
        }
    }

}