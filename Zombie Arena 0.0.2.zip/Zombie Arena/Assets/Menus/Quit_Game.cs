﻿using UnityEngine;
using UnityEngine.UI;

namespace Gamemenu
{

    public class Quit_Game : MonoBehaviour
    {
        private Button button;


        void Start()
        {
            button = GetComponentInChildren<Button>();
        }


        void Update()
        {
            button.onClick.AddListener(Quitgame);
        }

        private void Quitgame()
        {
            Application.Quit();
        }
    }

}