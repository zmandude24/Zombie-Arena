﻿using UnityEngine;

public class Status : MonoBehaviour
{
    public enum State {Alive, Dead}

    public State state;
    public int maxHealth = 100;

    public int health;


    void Start()
    {
        state = State.Alive;
        health = maxHealth;
    }


    void Update()
    {
        if (state == State.Alive)
        {
            // Stop Overhealing
            if (health > maxHealth)
                health = maxHealth;

            // Dying
            else if (health <= 0)
            {
                health = 0;
                state = State.Dead;
            }
        }
    }
}
