﻿using UnityEngine;
using UnityEngine.UI;

namespace Player
{

    public class HealthDisplay : MonoBehaviour
    {
        [SerializeField] private Status player = null;
        [SerializeField] private Text text = null;


        void Start()
        {
            text.text = "Loading";
        }


        void Update()
        {
            text.text = "Health: " + player.health.ToString() + " / " + player.maxHealth.ToString();
        }
    }

}