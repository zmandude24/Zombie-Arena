﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Player
{

    public class Death : MonoBehaviour
    {
        [SerializeField] private Status player = null;
        private Image[] images;
        private Text text;


        void Start()
        {
            images = GetComponentsInChildren<Image>();
            text = GetComponentInChildren<Text>();
            DeathScreen(false);
        }


        void Update()
        {
            if (player.state == Status.State.Dead && text.enabled == false)
                DeathScreen(true);
        }

        void DeathScreen(bool on_off)
        {
            foreach (Image image in images)
            {
                Button[] buttons = image.GetComponentsInChildren<Button>();
                if (buttons != null)
                {
                    // Disable or Enable the buttons
                    foreach (Button button in buttons)
                    {
                        Text buttontext = button.GetComponentInChildren<Text>();
                        buttontext.enabled = on_off;
                        button.enabled = on_off;
                    }
                }

                image.enabled = on_off;
            }
            text.enabled = on_off;
        }
    }

}