﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Player
{

    public class Camera : MonoBehaviour
    {
        [SerializeField] private float zoomSensitivity = 10.0f;
        [SerializeField] private float maxZoom = 10f;

        [SerializeField] private float horizontalSensitivity = 10.0f;
        [SerializeField] private float verticalSensitivity = 10.0f;
        [SerializeField] private float minVerticalAngle = -75.0f;
        [SerializeField] private float maxVerticalAngle = 75.0f;
        [SerializeField] private bool invertVertical = true;

        [SerializeField] private CharacterController player;

        // these are polar coordinates with -z acting as x
        private float radius;   // how far the camera is out
        private float theta;    // the vertical angle in 


        void Update()
        {
            radius = Mathf.Sqrt(transform.localPosition.y * transform.localPosition.y + transform.localPosition.z * transform.localPosition.z);
            theta = Mathf.Rad2Deg * Mathf.Asin(transform.localPosition.y / radius);
            Zoom();
            Rotate();
        }

        private void Zoom()
        {
            radius -= zoomSensitivity * Input.GetAxis("Mouse ScrollWheel");
            if (radius < 1e-5f) radius = 1e-5f;
            else if (radius > maxZoom) radius = maxZoom;
            MoveCamera();
        }

        private void Rotate()
        {
            float horizontalRotation = 36 * Input.GetAxis("Mouse X") * horizontalSensitivity * Time.deltaTime;
            player.transform.Rotate(0.0f, horizontalRotation, 0.0f);

            if (invertVertical) theta -= 9 * Input.GetAxis("Mouse Y") * verticalSensitivity * Time.deltaTime;
            else theta += 9 * Input.GetAxis("Mouse Y") * verticalSensitivity * Time.deltaTime;
            if (theta > maxVerticalAngle) theta = maxVerticalAngle;
            else if (theta < minVerticalAngle) theta = minVerticalAngle;
            MoveCamera();
        }

        private void MoveCamera()
        {
            float y = radius * Mathf.Sin(Mathf.Deg2Rad * theta);
            float z = -radius * Mathf.Cos(Mathf.Deg2Rad * theta);
            transform.localPosition = new Vector3(transform.localPosition.x, y, z);
            transform.localEulerAngles = new Vector3(theta, transform.localEulerAngles.y, transform.localEulerAngles.z);
        }
    }

}