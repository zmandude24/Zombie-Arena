﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Player
{

    public class Death : MonoBehaviour
    {
        [SerializeField] private Status player;
        [SerializeField] private Image image;
        [SerializeField] private Text text;


        void Start()
        {
            image.enabled = false;
            text.enabled = false;
        }


        void Update()
        {
            if (player.state == Status.State.Dead)
            {
                image.enabled = true;
                text.enabled = true;
            }
            else
            {
                image.enabled = false;
                text.enabled = false;
            }
        }
    }

}